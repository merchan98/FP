/* Programa para calcular el el sario de un centro de atenci�n 
   telef�nica con la inclusion de varios valores
*/


#include <iostream>   // Inclusi�n de los recursos de E/S
#include <cmath>      // Inclusi�n de los recursos matem�ticos

using namespace std; 

int main(){                    // Programa Principal
double salxhora;                // Declara de variables y constantes
int horas_traba;              
int cas_resul;
int gra_satis;
double sueldo_satis ;
double sueldo_resul ;
const int GRATISF = 30 ;
const int PORGATISF = 4;
const int PORSATIS = 2;
const int PORCENTAJE =100;

cout << "Introduce el precio de cada hora trabajada: "; // Introducion de los valores necesarios
cin >> salxhora ;

cout << "Introduce las horas trabajadas: ";
cin >> horas_traba ;

cout << "Introduce los casos resueltos satisfatoriamente: ";
cin >> cas_resul ;

cout << "Introduce el grado de satisfacci�n de los usuarios ( 0 a 5): ";
cin >> gra_satis ;
 
 
 
int sueldo_base = salxhora * horas_traba; // C�lculo del sueldo base

if (cas_resul > GRATISF) { // C�lculo  si la condicion se supera del plus de sueldo
	
   sueldo_resul = ((sueldo_base * PORGATISF)/PORCENTAJE);

}

if ( gra_satis >= PORGATISF) { // CAlculo  si la condicion se supera del plus de sueldo
	
	sueldo_satis = ((sueldo_base * PORSATIS)/PORCENTAJE) ;
	
}
 
double  sueldo_total = sueldo_base + sueldo_resul + sueldo_satis ; //Suma de los c�lculos anteriores al sueldo base
 
 cout << "El salario total es de " << sueldo_total << " � \n";
 
   system("pause");
}
