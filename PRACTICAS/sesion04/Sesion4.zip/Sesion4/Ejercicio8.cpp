/* Programa para calcular si un a�o es visiesto o no

*/

#include <iostream>   // Inclusi�n de los recursos de E/S
#include <cmath>      // Inclusi�n de los recursos matem�ticos

using namespace std; 

int main(){                    // Programa Principal

int ano;               // Declaracion de variables 



cout << "Introduce el a�o: ";  // Peticion de la varible que se necesita
cin >> ano ;



 
if ((((ano % 4) ==0 ) && ((ano % 100 ) != 0)) || ((ano % 400 ) == 0)) {  // Condicion si es bisiesto o no
	

 cout << "El a�o "<< ano <<" es bisiesto \n"; // Si lo es

}

else { 

 cout << "El a�o "<< ano <<" no es bisiesto \n"; // No lo es
}

 
   system("pause");
}
