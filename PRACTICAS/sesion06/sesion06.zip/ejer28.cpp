/* 28. Se quiere construir un programa para leer los datos necesarios del ejercicio 11 de la
subida salarial.
Supondremos que s�lo hay tres empleados y que est�n identificados con un c�digo
(1, 2 y 3). Adem�s, el salario por hora es el mismo para todos los empleados. �ste
ser� el primer valor que se leer� (de tipo double) Despu�s de haber le�do este dato,
se leer�n los datos de los casos atendidos por los empleados en el siguiente orden:
en primer lugar, el c�digo del empleado, a continuaci�n el n�mero de segundos que
ha durado la atenci�n telef�nica, en tercer lugar un 1 si el caso se resolvi� de forma
satisfactoria y un 0 en caso contrario; finalmente, un valor entero entre 0 y 5 con el
grado de satisfacci�n del usuario.
Cuando nos encontremos el terminador -1 como primer dato (c�digo del empleado)
se detendr� la introducci�n de datos. Supondremos que siempre se introduce al menos
el primer valor (el salario), pudiendo ser ya el siguiente dato le�do el terminador.
7.5 <- Salario de 7.5 euros por hora
2 124 1 3 <- Empleado 2, 124'', resuelto, grado sat: 3
1 32 0 0 <- Empleado 1, 32'' , no resuelto, grado sat: 0
2 26 0 2 <- Empleado 2, 26'' , no resuelto, grado sat: 2
-1 <- Fin de entrada de datos
El programa debe imprimir el n�mero total de casos introducidos (3 en el ejemplo
anterior) y el c�digo del empleado con mayor grado de satisfacci�n medio (tambi�n
imprimir� dicho grado medio. En el ejemplo anterior, ser�a el empleado 2 con un nivel
medio de satisfacci�n de 2.5.
Observe que, en este ejercicio, no se est�n teniendo en cuenta los datos referentes
al tiempo de cada caso y si fue resuelto o no, pero hay que leer todos los datos para
llegar a los que s� nos interesan.
Ejemplo de entrada: 7.5 2 124 1 3 1 32 0 0 2 26 0 2 -1
.... Salida correcta: 3 2 2.5
Ejemplo de entrada: 7.5 -1
.... Salida correcta: No se introdujo ning�n caso */

	#include <iostream> 
 
	using namespace std;    
 
	int main() {
    
    const int TERMINADOR = -1;
    double salario;
    double grad_empleado1 = 0, grad_empleado2 = 0, grad_empleado3 = 0;
    int cont_empleado1 = 0, cont_empleado2 = 0, cont_empleado3 = 0;
    int codigo, leido;
     
    do{
        cout << "\nIntroducir el salario de los empleados: ";
        cin >> salario;
    }while(salario < 0);
 
    cout << "\nCodigo del empleado: ";
    cin >> codigo;
    while(codigo != TERMINADOR){
        cout << "\nDuracion de la ayuda telefonica: ";
        cin >> leido;
        cout << "\nCliente satisfecho (0 = no / 1 = si): ";
        cin >> leido;
        do{
            cout << "\nGrado de satisfacion (entre 0 y 5): ";
            cin >> leido;
        }while(leido < 0 || leido > 5);
         
        if(codigo == 1){
            cont_empleado1++;
            grad_empleado1 += leido;
        }else if(codigo == 2){
            cont_empleado2++;
            grad_empleado2 += leido;
        }else{
            cont_empleado3++;
            grad_empleado3 += leido;
        }
        cout << "\nCodigo del empleado: ";
        cin >> codigo;
    }
     
     
    if(cont_empleado1 > 1)
        grad_empleado1/=cont_empleado1;
    if(cont_empleado2 > 1)
        grad_empleado2/=cont_empleado2;
    if(cont_empleado3 > 1)
        grad_empleado3/=cont_empleado3;
     
    int codigo_maximo;
    double grado_maximo;
     
    if(grad_empleado1 > grad_empleado2){
        if(grad_empleado1 > grad_empleado3){
            codigo_maximo = 1;
            grado_maximo = grad_empleado1;
        }else{
            codigo_maximo = 3;
            grado_maximo = grad_empleado3;
        }
    }else{
        if(grad_empleado3 > grad_empleado2){
            codigo_maximo = 3;
            grado_maximo = grad_empleado3;
        }else{
            codigo_maximo = 2;
            grado_maximo = grad_empleado2;
        }
    }
     
    cout << "\n\nTotal de Casos: " << cont_empleado1 + cont_empleado2 + cont_empleado3;
    cout << "\nEmpleado con el mayor grado medio de satisfacion: " << codigo_maximo;
    cout << "\nGrado medio de satisfacion: " << grado_maximo;
    
    return 0;
	}
