/*31. El algoritmo de la multiplicaci�n rusa es una forma distinta de calcular la multiplicaci�n
de dos n�meros enteros n * m. Para ello este algoritmo va calculando el doble del
multiplicador m y la mitad (sin decimales) del multiplicando n hasta que n tome el
valor 1 y suma todos aquellos multiplicadores cuyos multiplicandos sean impares. Por
ejemplo, para multiplicar 37 y 12 se har�an las siguientes iteraciones:

Iteraci�n 		Multiplicando 		Multiplicador
	1 				37 					12
	2 				18 					24
	3 				9 					48
	4 				4 					96
	5 				2 					192
	6 				1 					384
	
Con lo que el resultado de multiplicar 37 y 12 ser�a la suma de los multiplicadores
correspondientes a los multiplicandos impares (en negrita), es decir
37*12=12+48+384=444
Cree un programa para leer dos enteros n y m y calcule su producto utilizando este
algoritmo. No puede utilizarse en ning�n momento el operador producto *. */

	#include <iostream> 
	#include <cmath>

	using namespace std; 

	int main() { 
	int m,n,x; 
	x=0; 

	cout << " Introduzca el primer multiplo" << endl;
	cin>>  m ; 
	
	cout << " Introduzca el segundo multiplo" << endl;
	cin>>  n; 

	while (m!=0){ 
	if (m%2!=0) 
	x=x+n; 
	m=m/2; 
	n=n*2; } 
	
	cout<<"\n El resultado es:  " << x <<endl; 

	}
