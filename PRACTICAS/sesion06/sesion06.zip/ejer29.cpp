/* 29. Construya un programa que calcule cu�ndo se produjo la mayor secuencia de d�as
consecutivos con temperaturas crecientes. El programa leer� una secuencia de reales
representando temperaturas, hasta llegar al -1 y debe calcular la subsecuencia de
n�meros ordenada, de menor a mayor, de mayor longitud.
El programa nos debe decir la posici�n donde comienza la subsecuencia y su longitud.
Por ejemplo, ante la entrada siguiente:
17.2 17.3 16.2 16.4 17.1 19.2 18.9 -1.0

el programa nos debe indicar que la mayor subsecuencia empieza en la posici�n 3 (en
el 16.2) y tiene longitud 4 (termina en 19.2)
Puede suponer que siempre se introducir� al menos un valor de temperatura.
Ejemplo de entrada: 17.2 17.3 16.2 16.4 17.1 19.2 18.9 -1
.... Salida correcta: 3 4
Ejemplo de entrada: 17.2 17.3 16.2 16.4 17.1 19.2 -1
.... Salida correcta: 3 4
Ejemplo de entrada: 17.2 17.3 -1 .... Salida correcta: 1 2
Ejemplo de entrada: 17.2 15.3 -1 .... Salida correcta: 1 1
Ejemplo de entrada: 17.2 -1 .... Salida correcta: 1 1 */

	#include <iostream> 
 
	using namespace std;    

	int main(){
    double anterior, actual;
    int posic_sub = 0, posic_actual = 0, posic_maxima;
    int long_maxima = 0, long_actual;
     
    cout << "Secuencia de temperaturas: ";
    cin >> anterior;
     
    if(anterior != -1){
        cin >> actual;
        posic_maxima = posic_sub = posic_actual = 1;
        long_maxima = long_actual = 1;
    }else
        actual = -1;
 
     
    while(actual != -1){
        posic_actual++;
         
        if(actual >= anterior){
            long_actual ++;
            if(posic_maxima == posic_sub)
                long_maxima++;
            else if(long_actual > long_maxima){
                long_maxima = long_actual;
                posic_maxima = posic_sub;
            }
        }else{
            long_actual = 1;
            posic_sub = posic_actual;
        }
         
        anterior = actual;
        cin >> actual;
    }
     
    cout << "\nLa longitud de mayor tama�o de subsecuencia: "  << long_maxima;
    cout << "\nComienza en la posicion: " << posic_maxima; 
    
	return 0;
}
