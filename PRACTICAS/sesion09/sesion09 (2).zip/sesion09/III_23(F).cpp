/*

*/

#include <iostream>
using namespace std;

class Recta{
	private:
		int A, B, C;
		int x, y;
		
	public:
	Recta(int valor1, int valor2, int valor3){
		SetA(valor1);
		SetB(valor2);
		SetC(valor3);
		
	}
	Recta(){
		::Recta(0, 0, 0);
	}
	void SetA(int valorA){
		A = valorA;
	}
	void SetB(int valorB){
		B = valorB;
	}
	void SetC(int valorC){
		C = valorC;
	}
	void SetX(double valorX){
		x = valorX;
	}
	void SetY(double valorY){
		y = valorY;
	}
	void GetX(){
		return x;
	}
	void GetY(){
		return y;
	}
	void GetA(){
		return A;
	}
	void GetB(){
		return B;
	}
	void GetC(){
		return C;
	}
	double Pendiente(){
		double pendiente;
		
		pendiente = - A / B;	
		
		return pendiente
	}
	
	double ObtenerOrdenada(double x){
		return (-C - x * A) / B;
	}
	
	double ObtenerAbcisa(double y){
		return (-C - y * B) / A;
	}
};


int main(){
	Recta primero, segundo;
	double pendiente1, pendiente2;
	int x, y, ordenada, abcisa, A, B, C;
	
	cout << "\nIntroduzca un valor para el primer par�metro(A), el segundo(B) y el tercero(C) de la primera recta: ";
	cin >> A;
	cin >> B;
	cin >> C;
	
	Recta primero.Recta(A, B, C);
	
	cout << "\nIntroduzca un valor para el primer par�metro(A), el segundo(B) y el tercero(C) de la segunda recta: ";
	cin>> A;
	cin >> B;
	cin >> C;
	
	Recta segundo.Recta(A, B, C);
	
	cout << "\nIntroduzca un valor para coordenada x e y de la primera recta: ";
	cin >> x;
	cin >> y;
	
	primero.SetX(x);
	primero.SetY(y);
	
	cout << "\nIntroduzca un valor para coordenada x e y de la segunda recta: ";
	cin >> segundo.x;
	cin >> segundo.y;
	
	segundo.SetX(x);
	segundo.SetY(y);
	
	pendiente1 = primero.Pendiente();
	pendiente2 = segundo.Pendiente();
	
	cout << "\nEl valor de la pendiente de la primera recta es de: " << pendiente1;
	cout << "\nEl valor de la pendiente de la segunda recta es de: " << pendiente2 << endl;
	cout << "\nIntroduzca un valor para la ordenada: ";
	cin >> ordenada;
	cout << "\nIntroduzca un valor para la abcisa: ";
	cin >> abcisa;
	
	x = primera_recta.ObtenerAbcisa(ordenada);
	y = primera_recta.ObtenerOrdenada(abcisa);
	
	cout << "\nLa abcisa de " << ordenada << " es: " << X << " ---> El punto: (" << X << ", " << ordenada << ")";
	cout << "\nLa ordenada de " << abcisa << " es: " << Y << " ---> El punto: (" << abcisa << ", " << Y << ")\n\n";
	
	system("PAUSE");
	return(0);
}
