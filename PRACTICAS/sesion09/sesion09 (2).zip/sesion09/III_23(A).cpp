/*

*/

#include <iostream>
using namespace std;

class Recta{
	public:
		int A = 0, B = 0, C = 0;
		int x, y;	
};

int main(){
	Recta primero, segundo;
	double pendiente1, pendiente2;
	
	cout << "\nIntroduzca un valor para el primer par�metro(A), el segundo(B) y el tercero(C) de la primera recta: ";
	cin >> primero.A;
	cin >> primero.B;
	cin >> primero.C;
	cout << "\nIntroduzca un valor para el primer par�metro(A), el segundo(B) y el tercero(C) de la segunda recta: ";
	cin>> segundo.A;
	cin >> segundo.B;
	cin >> segundo.C;
	cout << "\nIntroduzca un valor para coordenada x e y de la primera recta: ";
	cin >> primero.x;
	cin >> primero.y;
	cout << "\nIntroduzca un valor para coordenada x e y de la segunda recta: ";
	cin >> segundo.x;
	cin >> segundo.y;
	
	pendiente1 = - primero.A / primero.B;
	pendiente2 = - segundo.A / segundo.B;
	
	cout << "\nEl valor de la pendiente de la primera recta es de: " << pendiente1;
	cout << "\nEl valor de la pendiente de la segunda recta es de: " << pendiente2 << endl;
	
	system("PAUSE");
	return(0);
}
