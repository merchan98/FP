/* Programa para calcular el interes dado por el ususrio sobre
un capital dado tambi�n por el usuario
  Formula
     Total = capital + capital * (interes / 100 ) 
*/

#include <iostream>   // Inclusi�n de los recursos de E/S

using namespace std; 

int main(){   
              
				     
double capital;   // Declaracion de variables
double interes;
double total;


cout << " Introduce el capital a ingresar: ";
cin >> capital ; //Lectura de datos introducidos por el usuario (CAPITAL)

cout << " Introduce el interes: ";
cin >> interes ; //Lectura de datos introducidos por el usuario (INTERES)

total = capital + capital * (interes / 100) ; // Formula para el calculo de inter�s


cout << " \n El capital total al acabo de un a�o con un interes del " << interes <<" % es de " << total << " � \n " ;




   system("pause");
}
