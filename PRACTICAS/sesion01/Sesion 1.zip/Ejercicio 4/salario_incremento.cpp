/* Programa para calcular apartir de un salario base introducido
por el usuario, incrementarle un 2% al sueldo base.
  Formula
      Salario final = Incremento * Salario base
*/

#include <iostream>   // Inclusi�n de los recursos de E/S

using namespace std; 

int main(){   
              
				     
double salario_base;   // Deficnicion de las variables y constante
double salario_final;
const double INCREMENTO = 1.02 ;


cout << " Introduce el salario base que se incrementara en un 2%: ";
cin >> salario_base ; //Lectura de los datos introducidos por el usuario

salario_final = INCREMENTO * salario_base ; //Formula para calcular el salario final


cout << " \n El salario final " << salario_final << " � \n " ;




   system("pause");
}
