/* Programa para calcular la funcion gussiana
  Formula
      gaussiana(x) = ((1/(sigma(sqrt(2*PI)))))* e ^(-05*((x- nu)/sigma)^2)
*/

#include <iostream>   // Inclusi�n de los recursos de E/S
#include <cmath>      // Inclusi�n de los recursos matem�ticos

using namespace std; 

int main(){                    // Programa Principal

double esperanza;        // Declaracion de variables
double desviacion;
double x;
long double fraccion_exponente, exponente, parte2, parte1, total ;
const double PI = 3.1416;

cout << "Introduce el valor de la espeanza(nu): ";   //Peticion de las variables
cin >> esperanza;

cout << "Introduce el valor de la desviaci�n(sigma): ";
cin >> desviacion;

cout << "Introduce el valor de x: " ;
cin >> x;

                                                         //Operaciones para la ecuaci�n
fraccion_exponente = ((x-esperanza)/desviacion);         //Fraci�n del exponente
exponente = -0.5 * (pow(fraccion_exponente,2)) ;         // Exponente entero
parte2 = exp(exponente) ;                                // Exponencial de n�mero e
parte1 = 1/(desviacion * (sqrt(2*PI))) ;                 // Fracion que multiplica al n� e
total = parte1*parte2 ;                                  // Multiplicaci�n de la exponencial con la fraci�n


cout << "El resultado de la ecuaci�n gaussiana con los datos introducidos es de " << total << "\n" ;

   system("pause");
}
