/* Programa para calcular apartir de un salario base introducido
por el usuario, incrementarle un 2% al sueldo base.
  Formula
      Salario final = Incremento * Salario base
*/

#include <iostream>   // Inclusi�n de los recursos de E/S
#include <cmath>      // Inclusi�n de los recursos matem�ticos

using namespace std; 

int main(){                    // Programa Principal
  
double salario_base;   // Definicion de las variables y constantes
double salario_final;
double salario_final_intermedio;
const double INCREMENTO2 = 1.02 ;
const double INCREMENTO3 = 1.03 ;


cout << " Introduce el salario base que se incrementara en un 2% y despu�s un 3%: ";
cin >> salario_base ; //Lectura de los datos introducidos por el usuario

salario_final = INCREMENTO2 * salario_base ; //Formula para calcular el salario final
salario_final_intermedio = INCREMENTO3 * salario_final ;


cout << " \n El salario final con un 2% de incremento es " << salario_final << " � \n " ;

cout << " \n El salario final con un 3% de incrmento sobre el salario anterior es" << salario_final_intermedio << " � \n " ;


   system("pause");
}
