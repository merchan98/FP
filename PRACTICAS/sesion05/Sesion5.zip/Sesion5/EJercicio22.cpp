/* Programa para calcular la funcion gussiana entre un max y un minimo dado un incremneto
  Formula
      gaussiana(x) = ((1/(sigma(sqrt(2*PI)))))* e ^(-05*((x- nu)/sigma)^2)
*/

#include <iostream>   // Inclusi�n de los recursos de E/S
#include <cmath>      // Inclusi�n de los recursos matem�ticos

using namespace std; 

int main(){                    // Programa Principal

double esperanza;        // Declaracion de variables
double desviacion;
double x;
double maximo;
double minimo;
double incremento;
long double fraccion_exponente, exponente, parte2, parte1, total ;
const double PI = 3.1416;



  cout << "Introduce el valor de la espeanza(nu): ";   //Peticion de las variables
  cin >> esperanza;

do {

  cout << "Introduce el valor de la desviaci�n(sigma): ";
  cin >> desviacion;

  if (desviacion < 0) {
	
     cout << "El valor introducido no es correcto, inserte uno mayor o igual que 0 \n"; //Error al introducir el dato
    }
  }
while (desviacion < 0) ;

cout << "Introduce el minimo valor de abcisas: ";
cin >> minimo ;

do {

bool maximo_si = (maximo < minimo);

cout << "Introduce el maximo valor de abcisas: ";
cin >> maximo;

if (maximo_si){
 cout << "EL valor introducido es menor que el valor minimo, vuelva introducir el valor \n"; //Error al introducir el dato

   }	
}
while (maximo < minimo);

cout << "Introduce el incremento:  ";
cin >> incremento;


x = minimo;
                                                         //Operaciones para la ecuaci�n
fraccion_exponente = ((x-esperanza)/desviacion);         //Fraci�n del exponente
exponente = -0.5 * (pow(fraccion_exponente,2)) ;         // Exponente entero
parte2 = exp(exponente) ;                                // Exponencial de n�mero e
parte1 = 1/(desviacion * (sqrt(2*PI))) ;                 // Fracion que multiplica al n� e
total = parte1*parte2 ;                                  // Multiplicaci�n de la exponencial con la fraci�n

cout << "El resultado de la ecuaci�n gaussiana con los datos introducidos es de " << total << "\n" ;


while (x < maximo){
	x = x + incremento;
	                                                         //Operaciones para la ecuaci�n
fraccion_exponente = ((x-esperanza)/desviacion);         //Fraci�n del exponente
exponente = -0.5 * (pow(fraccion_exponente,2)) ;         // Exponente entero
parte2 = exp(exponente) ;                                // Exponencial de n�mero e
parte1 = 1/(desviacion * (sqrt(2*PI))) ;                 // Fracion que multiplica al n� e
total = parte1*parte2 ;                                  // Multiplicaci�n de la exponencial con la fraci�n

cout << "El resultado de la ecuaci�n gaussiana con los datos introducidos es de " << total << "\n" ;	
	
}

   system("pause");
}
