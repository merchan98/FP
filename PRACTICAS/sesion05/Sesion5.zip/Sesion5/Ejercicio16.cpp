/* Programa para saber si el orden de los n�meros
   introsucidos es acendente, descente, o ninguno
*/

#include <iostream>   // Inclusi�n de los recursos de E/S
#include <cmath>      // Inclusi�n de los recursos matem�ticos

using namespace std; 

int main(){                    // Programa Principal

int x;               // Declaracion de variables 
int y;               
int z;


cout << "Introduce el primer valor: "; //Introsucion de los valores necesarios
cin >> x ;

cout << "Introduce el segundo valor: ";
cin >> y;

cout << "Introduce el tercer valor: ";
cin >> z ;

 
bool descendiente = (x > y && y > z && z < x) ;
bool ascendente = (x < y && y < z && z > x) ;
bool igual = (x == y && y == z && z == x) ;

if (igual) { // Saber si es igual


 cout << "Los tres numeros son iguales \n" ;
}

else {if (descendiente) {  // Saber si es orden descentente
	
         cout << "Esta ordenado en orden descentente \n";

         }

      else { 
		      if (ascendente) {  //Saber si el orden es ascentente

            cout << "Esta ordenado en orden ascendente \n";
            }

            else {  //Ninguno de los anteriores casos ocurre

               cout << "La secuencia introducida no esta ordenada ni ascendente ni descendente  \n";
 
                }
           }
    }

 system("pause");
}
