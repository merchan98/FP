/* Programa para calcular la poblaci�n despues de los a�os introducidos dada la poblacio�n inical, las tasas de mortalidad. natalidad y migraci�n
  Las tasas son a tanto por mil, y se aplican cosecutivamente cada a�o 
*/

#include <iostream>   // Inclusi�n de los recursos de E/S
#include <cmath>      // Inclusi�n de los recursos matem�ticos

using namespace std; 

int main(){                    // Programa Principal
const int DOBLE = 2 ;   // Defici�n de variables 
const int PORMIL = 1000 ;         
double tasa_mortalidad;
double tasa_natalidad;
double tasa_migracion;
double anios_transcurridos;
int long long pob_inicial, pob_total, poblacion_doble;
int anios = 0;

cout << "Introduce los datos necesarios sin signo ni simbolo de porcentaje.  \n ";

do {

 cout << "Introduce la poblaci�n inicial: "; // Introduccion de la poblacion inical
 cin >> pob_inicial;
 
 if (pob_inicial <= 0){
 cout << "EL valor introducido es incorrecto, por favor introduce un n�mero mayor que 0\n"; //Error al introducir el dato
 }
}
while (pob_inicial <= 0);

do {

 cout << "Introduce la tasa de natalidad: "; // Introduccion de la tasa natalidad
 cin >> tasa_natalidad;

 if (tasa_natalidad < 0 && tasa_natalidad > PORMIL){
 cout << "EL valor introducido es incorrecto, por favor introduce un n�mero entre 0 y 1000 \n"; //Error al introducir el dato
 }
  }
while (tasa_natalidad < 0 && tasa_natalidad > PORMIL) ;

do {

 cout << "Introduce la tasa de mortalidad (sin signo): " ; // Introduccion de la tasa mortalidad
 cin >> tasa_mortalidad ;
 
 if (tasa_mortalidad < 0 && tasa_mortalidad > PORMIL){
 cout << "EL valor introducido es incorrecto, por favor introduce un n�mero entre 0 y 1000 \n"; //Error al introducir el dato
 }
}
while (tasa_mortalidad < 0 && tasa_mortalidad > PORMIL);

do {

 cout << "Introduce la tasa de migraci�n : " ;// Introduccion de la tasa migracion
 cin >> tasa_migracion;

 if (tasa_migracion < -PORMIL && tasa_migracion > PORMIL){
 cout << "EL valor introducido es incorrecto, por favor introduce un n�mero entre 0 y 1000 \n"; //Error al introducir el dato
 }
}
while (tasa_migracion < -PORMIL && tasa_migracion > PORMIL);

cout << "Introduce el a�os transcurridos: ";// Introduccion de los a�os que se necita la poblacion
cin >> anios_transcurridos;

poblacion_doble = DOBLE * pob_inicial ; //C�lculo de la poblaci�n doble 
pob_total = pob_inicial;

do { //Bucle de calculo de la poblacion para los a�os indicados
	
anios++ ;

pob_total = pob_total + ((pob_total * tasa_natalidad )/PORMIL) - ((pob_total * tasa_mortalidad )/PORMIL) + ((pob_total * tasa_migracion )/PORMIL)  ;  //Poblaci�n primer a�o

}
while (anios < anios_transcurridos);

cout << "La poblacion pasados " << anios_transcurridos << " a�os es de " << pob_total << " habitantes.\n" ;

anios = 0;

do { //Bucle de calculo de los a�os que hacen falta para que lleguen los habitantes al doble de los iniciales
	
anios++ ;

pob_inicial = pob_inicial + ((pob_inicial * tasa_natalidad )/PORMIL) - ((pob_inicial * tasa_mortalidad )/PORMIL) + ((pob_inicial * tasa_migracion )/PORMIL)  ;  //Poblaci�n primer a�o
	

}
while (pob_inicial < poblacion_doble);

cout << "Se necitaran " << anios << " a�os para llegar al doble de la poblacion inicial. La poblacion despues los a�os dichos anteriormente es de "<< pob_inicial << " habitantes\n";



   system("pause");
}
